package jp.example;


import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class M_MenuPanel extends JPanel implements ActionListener{
	private JTable table;
	private JTextField textField;//メニュー名
	private JTextField textField_1;//メニュー金額
	private JTextField textField_2;//削除するID
	private JTextField textField_5;//所要時間

	Object[][] ob;
	String[] koumoku = {"メニューID","メニュー名","所要時間","金額"};


	/**
	 * Create the panel.
	 */
	public M_MenuPanel() {

		setBounds(0, 0, 562, 529);

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(448, 474, 73, 21);
		ReturnButton.addActionListener(this);
		setLayout(null);
		ReturnButton.setActionCommand("店長へ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("メニュー管理パネル");
		lblNewLabel.setBounds(12, 10, 105, 13);
		add(lblNewLabel);


		AccessDB.getInstance().connect();

		final DefaultTableModel model = new DefaultTableModel(ob,koumoku);
		table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(table);

		scrollPane.setBounds(36, 46, 470, 214);
		add(scrollPane);
		ArrayList<M_menu> list2 = new ArrayList<>();


		for(M_menu m : list2) {
			Object[] o = {m.getMenuid(),m.getMenuname(),m.getPrice()};
			model.addRow(o);
		}

		AccessDB.getInstance().disconnect();




		JButton btnNewButton_2 = new JButton("一覧表示");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);
				ArrayList<M_menu> list = new ArrayList<>();
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_menuList();
				AccessDB.getInstance().disconnect();
				for(M_menu m : list) {
					Object[] o = {m.getMenuid(),m.getMenuname(),m.getMenutime(),m.getPrice()};
					model.addRow(o);
				}
			}
		});

		btnNewButton_2.setBounds(217, 15, 87, 21);
		add(btnNewButton_2);



		JLabel lblNewLabel_1 = new JLabel("メニューの追加");
		lblNewLabel_1.setBounds(36, 312, 108, 13);
		add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("メニューの削除");
		lblNewLabel_2.setBounds(36, 432, 108, 13);
		add(lblNewLabel_2);


		//メニューの追加項目（画面中段）
		JLabel lblNewLabel_3 = new JLabel("メニュー名");
		lblNewLabel_3.setBounds(156, 286, 86, 13);
		add(lblNewLabel_3);

		//メニュー名入力
		textField = new JTextField();
		textField.setBounds(156, 309, 111, 19);
		add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("金額");
		lblNewLabel_4.setBounds(279, 286, 45, 13);
		add(lblNewLabel_4);
		//金額入力
		textField_1 = new JTextField();
		textField_1.setBounds(279, 309, 86, 19);
		add(textField_1);
		textField_1.setColumns(10);


		JLabel lblNewLabel_8 = new JLabel("所要時間");
		lblNewLabel_8.setBounds(377, 286, 50, 13);
		add(lblNewLabel_8);

		//時間入力
		textField_5 = new JTextField();
		textField_5.setBounds(387, 309, 96, 19);
		add(textField_5);
		textField_5.setColumns(10);

		JButton btnNewButton2 = new JButton("登録");
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//処理する内容を書く
				String menuname = textField.getText();
				int price = Integer.parseInt(textField_1.getText());
				int time = Integer.parseInt(textField_5.getText());

				//データベースからメニューIDを引っ張ってくる(全件取得からID抽出)
				ArrayList<M_menu> list = new ArrayList<>();
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_menuList();
				AccessDB.getInstance().disconnect();
				int max = 0;
				for(M_menu i : list){
					if(i.getMenuid() > max) {
						max = i.getMenuid();
					}
				}
				max++;//メニューIDを更新

				//データベースに追加
				AccessDB.getInstance().connect();
				int x = AccessDB.getInstance().insertM_menu(max, menuname,time, price);
				AccessDB.getInstance().disconnect();

				//こっちの方が使い勝手いいかも

				//JDialogのインスタンスを作る
				JDialog d = new JDialog();
				//ダイアログにタイトルをつける
				d.setTitle("メニュー新規登録");
				//ダイアログのサイズを指定する
				d.setSize(300, 200);
				//ダイアログの表示場所。Nullなら画面中央。
				d.setLocationRelativeTo(null);
				// ダイアログをモーダルダイアログとして設定
				// モーダルの時は他のウインドウとかの操作をブロックできる
				d.setModal(true);

				JLabel messageLabel = new JLabel("一件登録しました");
				messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
				d.getContentPane().add(messageLabel, BorderLayout.CENTER);

				// ダイアログにコンポーネントを追加
				//								// ダイアログにテキストフィールドを追加
				//								JTextField textField = new JTextField();
				//								d.getContentPane().add(textField, BorderLayout.NORTH);
				// ダイアログにボタンを追加
				JButton dialogButton = new JButton("OK");


				dialogButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						d.dispose(); // Close the dialog
					}
				});
				d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
				// ダイアログの表示
				d.setVisible(true);
			}
		});


		btnNewButton2.setBounds(236, 343, 87, 21);
		add(btnNewButton2);

		//メニューの削除（画面下段）
		JLabel lblNewLabel_5 = new JLabel("削除したいメニューIDを入力");
		lblNewLabel_5.setBounds(156, 412, 148, 13);
		add(lblNewLabel_5);

		//ID入力
		textField_2 = new JTextField();
		textField_2.setBounds(156, 429, 86, 19);
		add(textField_2);
		textField_2.setColumns(10);

		JButton btnNewButton_1 = new JButton("削除");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = Integer.parseInt(textField_2.getText());

				AccessDB.getInstance().connect();
				int x = AccessDB.getInstance().menuDelete(id);
				AccessDB.getInstance().disconnect();
				JDialog d = new JDialog();
				//ダイアログにタイトルをつける
				d.setTitle("メニュー変更");
				//ダイアログのサイズを指定する
				d.setSize(300, 200);
				//ダイアログの表示場所。Nullなら画面中央。
				d.setLocationRelativeTo(null);
				// ダイアログをモーダルダイアログとして設定
				// モーダルの時は他のウインドウとかの操作をブロックできる
				d.setModal(true);

				JLabel messageLabel = new JLabel("一件削除しました");
				messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
				d.getContentPane().add(messageLabel, BorderLayout.CENTER);

				// ダイアログにコンポーネントを追加
				// ダイアログにボタンを追加
				JButton dialogButton = new JButton("OK");


				dialogButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						d.dispose(); // Close the dialog
					}
				});
				d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
				// ダイアログの表示
				d.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(278, 428, 87, 21);
		add(btnNewButton_1);


		//		
		//		JButton btnNewButton_1 = new JButton("削除");
		//		btnNewButton_1.addActionListener(new ActionListener() {
		//			public void actionPerformed(ActionEvent e) {
		//				//処理する内容を書く

		//メニューの変更（画面下段）
		//		JLabel lblNewLabel_5 = new JLabel("削除したいメニューIDを入力");
		//		lblNewLabel_5.setBounds(156, 412, 148, 13);
		//		add(lblNewLabel_5);
		//		//ID入力
		//		textField_2 = new JTextField();
		//		textField_2.setBounds(156, 429, 86, 19);
		//		add(textField_2);
		//		textField_2.setColumns(10);
		//		
		//		JButton btnNewButton_1 = new JButton("削除");
		//		btnNewButton_1.addActionListener(new ActionListener() {
		//			public void actionPerformed(ActionEvent e) {
		//				//処理する内容を書く
		//				int id = Integer.parseInt(textField_2.getText());
		//				//String menuname2 = textField_3.getText();
		//				int time = Integer.parseInt(textField_5.getText());
		//				//int price2 = Integer.parseInt(textField_4.getText());
		//				
		//				AccessDB.getInstance().connect();
		//				int x = AccessDB.getInstance().updateM_menu(id, menuname2,time, price2);
		//				AccessDB.getInstance().disconnect();
		//				
		//				//こっちの方が使い勝手いいかも
		//
		//				//JDialogのインスタンスを作る
		//								JDialog d = new JDialog();
		//								//ダイアログにタイトルをつける
		//								d.setTitle("メニュー変更");
		//								//ダイアログのサイズを指定する
		//								d.setSize(300, 200);
		//								//ダイアログの表示場所。Nullなら画面中央。
		//								d.setLocationRelativeTo(null);
		//								// ダイアログをモーダルダイアログとして設定
		//								// モーダルの時は他のウインドウとかの操作をブロックできる
		//								d.setModal(true);
		//								
		//								JLabel messageLabel = new JLabel("一件変更しました");
		//								messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		//								d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		//
		//								// ダイアログにコンポーネントを追加
		//								// ダイアログにテキストフィールドを追加
		//								JTextField textField = new JTextField();
		//								d.getContentPane().add(textField, BorderLayout.NORTH);
		//								// ダイアログにボタンを追加
		//								JButton dialogButton = new JButton("OK");
		//								
		//								
		//								dialogButton.addActionListener(new ActionListener() {
		//								    public void actionPerformed(ActionEvent e) {
		//								        d.dispose(); // Close the dialog
		//								    }
		//								});
		//								d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		//								// ダイアログの表示
		//								d.setVisible(true);
		//							}
		//						});
		//		btnNewButton_1.setBounds(278, 428, 87, 21);
		//		add(btnNewButton_1);


	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("店長へ")) {
			Main.card.show(Main.CardLayoutPanel, "店長パネル");
		}		
	}
}
