package jp.example;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class C_EntryPanel extends JPanel implements ActionListener{
	private DefaultTableModel model;
	/**
	 * Create the panel.
	 */
	public C_EntryPanel() {
		setBounds(0, 0, 562, 529);//パネルサイズ
		setLayout(null);//絶対レイアウト

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(454, 495, 73, 21);
		ReturnButton.addActionListener(this);
		ReturnButton.setActionCommand("メインへ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("顧客台帳パネル");
		lblNewLabel.setBounds(36, 31, 143, 13);
		add(lblNewLabel);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 321, 474, 103);
		add(scrollPane);

		//		JTextField customerid = new JTextField();
		//		customerid.setBounds(124, 262, 96, 19);
		//		add(customerid);
		//		customerid.setColumns(10);

		JTextField customername = new JTextField();
		customername.setBounds(152, 89, 115, 19);
		add(customername);
		customername.setColumns(10);

		JTextField tel = new JTextField();
		tel.setBounds(152, 163, 115, 19);
		add(tel);
		tel.setColumns(10);

		JTextField email = new JTextField();
		email.setBounds(362, 163, 115, 19);
		add(email);
		email.setColumns(10);

		JLabel lblNewLabel_7 = new JLabel("氏名");
		lblNewLabel_7.setBounds(71, 92, 50, 13);
		add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("TEL");
		lblNewLabel_8.setBounds(71, 166, 50, 13);
		add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("E-mail");
		lblNewLabel_9.setBounds(300, 166, 50, 13);
		add(lblNewLabel_9);

		//		JLabel lblNewLabel_10 = new JLabel("顧客番号");
		//		lblNewLabel_10.setBounds(62, 265, 50, 13);
		//		add(lblNewLabel_10);

		//		JLabel lblNewLabel_1 = new JLabel("(4桁の数字を入力)");
		//		lblNewLabel_1.setBounds(59, 291, 175, 13);
		//		add(lblNewLabel_1);

		String[] customerColumnNames = {"顧客番号","氏名","TEL","E-mail"};
		Object[][] customerData = {};

		model = new DefaultTableModel(customerData,customerColumnNames);
		JTable table = new JTable(model);
		scrollPane.setViewportView(table);

		//		//変更
		//		JButton customerUpdata = new JButton("変更");
		//		customerUpdata.setBounds(161, 434, 91, 21);
		//		add(customerUpdata);
		//		customerUpdata.addActionListener(new ActionListener() {
		//			public void actionPerformed(ActionEvent e) {
		//				if(customerid.getText().isBlank()) {
		//					chkinput("顧客番号");
		//				}else {
		//					AccessDB.getInstance().connect();
		//					M_customer m_customer =	AccessDB.getInstance().getM_customer(Integer.parseInt(customerid.getText()));
		//					String Name = customername.getText();
		//					String Tel = tel.getText();
		//					String Email = email.getText();
		//					if(customername.getText().isBlank()) {
		//						Name = m_customer.getCustomername();
		//					}
		//					if(tel.getText().isBlank()) {
		//						Tel = m_customer.getTel();
		//					}
		//					if(email.getText().isBlank()) {
		//						Email = m_customer.getEmail();
		//					}
		//					AccessDB.getInstance().updateM_customer(Integer.parseInt(customerid.getText()), Name, Tel,Email);
		//					AccessDB.getInstance().disconnect();
		//
		//					dialog("顧客情報変更","変更しました");
		//
		//					model.setRowCount(0);
		//					ArrayList<M_customer> list = new ArrayList<>();
		//					AccessDB.getInstance().connect();
		//					list = AccessDB.getInstance().getM_customerList();
		//					AccessDB.getInstance().disconnect();
		//					for(M_customer m : list) {
		//						Object[] o = {m.getCustomerid(),m.getCustomername(),m.getTel(),m.getEmail()};
		//						model.addRow(o);
		//					}
		//				}	
		//			}
		//		});

		//登録
		JButton customerInsert = new JButton("登録");
		customerInsert.setBounds(350, 260, 143, 25);
		add(customerInsert);
		customerInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);

				//データベースからメニューIDを引っ張ってくる(全件取得からID抽出)
				ArrayList<M_customer> list = new ArrayList<>();
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_customerList();
				AccessDB.getInstance().disconnect();
				int max = 0;
				for(M_customer i : list){
					if(i.getCustomerid() > max) {
						max = i.getCustomerid();
					}
				}
				max++;

				if(customername.getText().isBlank()) {
					dialog("入力エラー","氏名を入力してください");
				}else if(tel.getText().isBlank()) {
					dialog("入力エラー","電話番号を入力してください");
				}else if(email.getText().isBlank()) {
					dialog("入力エラー","メールアドレスを入力してください");
				}else{	AccessDB.getInstance().connect();	
				AccessDB.getInstance().insertM_customer(max,customername.getText(), tel.getText(),email.getText());
				AccessDB.getInstance().disconnect();	
				Object[] o = {max,customername.getText(), tel.getText(),email.getText()};
				model.addRow(o);
				dialog("顧客台帳新規登録","登録しました");
				}
			}
		});

		//		//削除
		//		JButton deleteFromCustomerList = new JButton("削除");
		//		deleteFromCustomerList.setBounds(58, 434, 91, 21);
		//		add(deleteFromCustomerList);
		//		deleteFromCustomerList.addActionListener(new ActionListener() {
		//			public void actionPerformed(ActionEvent e) {
		//				if(customerid.getText().isBlank()) {
		//					chkinput("顧客番号");
		//				}else {
		//
		//					AccessDB.getInstance().connect();
		//					AccessDB.getInstance().deleteFromCustomerList(Integer.parseInt(customerid.getText()));
		//					AccessDB.getInstance().disconnect();
		//					dialog("顧客情報削除","削除しました");
		//					model.setRowCount(0);
		//					ArrayList<M_customer> list = new ArrayList<>();
		//					AccessDB.getInstance().connect();
		//					list = AccessDB.getInstance().getM_customerList();
		//					AccessDB.getInstance().disconnect();
		//					for(M_customer m : list) {
		//						Object[] o = {m.getCustomerid(),m.getCustomername(),m.getTel(),m.getEmail()};
		//						model.addRow(o);
		//					}
		//					customerid.setText("");
		//				}
		//			}
		//		});

		//テキストフィールドを空にする
		JButton clear = new JButton("入力内容クリア");
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//				customerid.setText("");
				customername.setText("");
				tel.setText("");
				email.setText("");
			}
		});
		clear.setBounds(350, 216, 143, 21);
		add(clear);
	}


	public void dialog(String messege1,String messege2) {

		JDialog d = new JDialog();
		d.setTitle(messege1);
		d.setSize(300, 200);
		d.setLocationRelativeTo(null);
		d.setModal(true);

		JLabel messageLabel = new JLabel(messege2);
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		JButton dialogButton = new JButton("OK");
		dialogButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.dispose(); // Close the dialog
			}
		});
		d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		d.setVisible(true);	
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("メインへ")) {
			model.setRowCount(0);
			Main.card.show(Main.CardLayoutPanel, "メインパネル");
		}		
	}
}
