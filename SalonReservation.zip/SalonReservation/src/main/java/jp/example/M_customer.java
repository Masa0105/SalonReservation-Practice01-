package jp.example;

public class M_customer {

	private int customerid;
	private String customername;
	private String tel;
	private String email;

	M_customer(){}
	
	M_customer(int customerid,String customername,String tel,String email){
		setCustomerid(customerid);
		setCustomername(customername);
		setTel(tel);
		setEmail(email);		
	}

	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
