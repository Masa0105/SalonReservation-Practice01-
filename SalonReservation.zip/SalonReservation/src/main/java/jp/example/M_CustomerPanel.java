package jp.example;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class M_CustomerPanel extends JPanel implements ActionListener{
	private DefaultTableModel model;
	private JTextField customerid;
	private JTextField customername;
	private JTextField tel;
	private JTextField email;

	ArrayList<M_customer> list = new ArrayList<>();

	/**
	 * Create the panel.
	 */
	public M_CustomerPanel() {
		setBounds(0, 0, 562, 529);//パネルサイズ
		setLayout(null);//絶対レイアウト

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(463, 481, 73, 21);
		ReturnButton.addActionListener(this);
		ReturnButton.setActionCommand("店長へ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("顧客台帳パネル");
		lblNewLabel.setBounds(36, 31, 143, 13);
		add(lblNewLabel);


		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 75, 474, 161);
		add(scrollPane);

		customerid = new JTextField();
		customerid.setBounds(124, 262, 96, 19);
		add(customerid);
		customerid.setColumns(10);

		customername = new JTextField();
		customername.setBounds(353, 262, 96, 19);
		add(customername);
		customername.setColumns(10);

		tel = new JTextField();
		tel.setBounds(124, 350, 96, 19);
		add(tel);
		tel.setColumns(10);

		email = new JTextField();
		email.setBounds(353, 350, 96, 19);
		add(email);
		email.setColumns(10);

		JLabel lblNewLabel_7 = new JLabel("氏名");
		lblNewLabel_7.setBounds(291, 265, 50, 13);
		add(lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("TEL");
		lblNewLabel_8.setBounds(62, 353, 50, 13);
		add(lblNewLabel_8);

		JLabel lblNewLabel_9 = new JLabel("E-mail");
		lblNewLabel_9.setBounds(291, 353, 50, 13);
		add(lblNewLabel_9);

		JLabel lblNewLabel_10 = new JLabel("顧客番号");
		lblNewLabel_10.setBounds(62, 265, 50, 13);
		add(lblNewLabel_10);

		JLabel lblNewLabel_1 = new JLabel("（削除・変更の場合は入力）");
		lblNewLabel_1.setBounds(59, 291, 175, 13);
		add(lblNewLabel_1);

		String[] customerColumnNames = {"顧客番号","氏名","TEL","E-mail"};
		Object[][] customerData = {};

		model = new DefaultTableModel(customerData,customerColumnNames);
		JTable table = new JTable(model);
		scrollPane.setViewportView(table);

		//表示
		JButton showCustomerList = new JButton("一覧表示");
		showCustomerList.setBounds(226, 44, 91, 21);
		add(showCustomerList);

		showCustomerList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_customerList();
				AccessDB.getInstance().disconnect();
				for(M_customer m : list) {
					Object[] o = {m.getCustomerid(),m.getCustomername(),m.getTel(),m.getEmail()};
					model.addRow(o);
				}
			}
		});

		//変更
		JButton customerUpdata = new JButton("変更");
		customerUpdata.setBounds(161, 434, 91, 21);
		add(customerUpdata);
		customerUpdata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(customerid.getText().isBlank()) {
					dialog("入力エラー","顧客番号を入力してください");
				}else {
					AccessDB.getInstance().connect();
					M_customer m_customer =	AccessDB.getInstance().getM_customer(Integer.parseInt(customerid.getText()));
					String Name = customername.getText();
					String Tel = tel.getText();
					String Email = email.getText();
					if(customername.getText().isBlank()) {
						Name = m_customer.getCustomername();
					}
					if(tel.getText().isBlank()) {
						Tel = m_customer.getTel();
					}
					if(email.getText().isBlank()) {
						Email = m_customer.getEmail();
					}
					AccessDB.getInstance().updateM_customer(Integer.parseInt(customerid.getText()), Name, Tel,Email);
					AccessDB.getInstance().disconnect();

					dialog("顧客情報変更","変更しました");

					model.setRowCount(0);
					AccessDB.getInstance().connect();
					list = AccessDB.getInstance().getM_customerList();
					AccessDB.getInstance().disconnect();
					for(M_customer m : list) {
						Object[] o = {m.getCustomerid(),m.getCustomername(),m.getTel(),m.getEmail()};
						model.addRow(o);
					}
				}
			}
		});

		//登録
		JButton customerInsert = new JButton("登録");
		customerInsert.setBounds(264, 434, 91, 21);
		add(customerInsert);
		customerInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//データベースからメニューIDを引っ張ってくる(全件取得からID抽出)
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_customerList();
				AccessDB.getInstance().disconnect();
				int max = 0;
				for(M_customer i : list){
					if(i.getCustomerid() > max) {
						max = i.getCustomerid();
					}
				}
				max++;

				if(customername.getText().isBlank()) {
					dialog("入力エラー","氏名を入力してください");
				}else if(tel.getText().isBlank()) {
					dialog("入力エラー","電話番号を入力してください");
				}else if(email.getText().isBlank()) {
					dialog("入力エラー","メールアドレスを入力してください");
				}else {
					AccessDB.getInstance().connect();	
					AccessDB.getInstance().insertM_customer(max,customername.getText(), tel.getText(),email.getText());
					AccessDB.getInstance().disconnect();		

					Object[] o = {max,customername.getText(),tel.getText(),email.getText()};
					model.addRow(o);

					dialog("新規登録","登録しました");
				}
			}
		});

		//削除
		JButton deleteFromCustomerList = new JButton("削除");
		deleteFromCustomerList.setBounds(58, 434, 91, 21);
		add(deleteFromCustomerList);
		deleteFromCustomerList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(customerid.getText().isBlank()) {
					dialog("入力エラー","顧客番号を入力してください");
				}else {

					//ダイアログ
					int ret = JOptionPane.showConfirmDialog(null, "本当に削除しますか？", "削除確認", JOptionPane.YES_NO_OPTION , JOptionPane.WARNING_MESSAGE);

					switch(ret) {
					case JOptionPane.YES_OPTION:
						AccessDB.getInstance().connect();
						int count = AccessDB.getInstance().deleteFromCustomerList(Integer.parseInt(customerid.getText()));
						AccessDB.getInstance().disconnect();

						if(count != 0) {
							model.setRowCount(0);
							AccessDB.getInstance().connect();
							list = AccessDB.getInstance().getM_customerList();
							AccessDB.getInstance().disconnect();
							for(M_customer m : list) {
								Object[] o = {m.getCustomerid(),m.getCustomername(),m.getTel(),m.getEmail()};
								model.addRow(o);
							}
							dialog("顧客情報削除","削除しました");
						}else {
							dialog("顧客情報削除","削除できませんでした");
						}
						customerid.setText("");
						break;

					case JOptionPane.NO_OPTION:
						dialog("顧客情報削除","削除を取りやめました");
						break;
					}
				}
			}
		});

		//テキストフィールドを空にする
		JButton clear = new JButton("入力内容クリア");
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				customerid.setText("");
				customername.setText("");
				tel.setText("");
				email.setText("");
			}
		});
		clear.setBounds(367, 434, 143, 21);
		add(clear);
	}



	public void dialog(String messege1,String messege2) {

		JDialog d = new JDialog();
		d.setTitle(messege1);
		d.setSize(300, 200);
		d.setLocationRelativeTo(null);
		d.setModal(true);

		JLabel messageLabel = new JLabel(messege2);
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		JButton dialogButton = new JButton("OK");
		dialogButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.dispose(); // Close the dialog
			}
		});
		d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		d.setVisible(true);	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("店長へ")) {
			customerid.setText("");
			customername.setText("");
			tel.setText("");
			email.setText("");
			model.setRowCount(0);
			Main.card.show(Main.CardLayoutPanel, "店長パネル");
		}
	}
}
