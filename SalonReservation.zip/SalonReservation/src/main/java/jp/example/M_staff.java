package jp.example;

public class M_staff {
	private int staffid;
	private String staffname;

	M_staff(){}

	M_staff(int staffid,String staffname){
		setStaffid(staffid);
		setStaffname(staffname);
	}

	public int getStaffid() {
		return staffid;
	}
	public void setStaffid(int staffid) {
		this.staffid = staffid;
	}
	public String getStaffname() {
		return staffname;
	}
	public void setStaffname(String staffname) {
		this.staffname = staffname;
	}

}
