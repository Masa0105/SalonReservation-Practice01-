package jp.example;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class C_ChangePanel extends JPanel implements ActionListener{
	private JTextField customerid;
	private JTextField id;

	ArrayList<M_menu> menulist = new ArrayList<>();
	ArrayList<M_staff> stafflist = new ArrayList<>();

	/**
	 * Create the panel.
	 */
	public C_ChangePanel() {

		setBounds(0, 0, 562, 529);//パネルサイズ
		setLayout(null);//絶対レイアウト

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(463, 481, 73, 21);
		ReturnButton.addActionListener(this);
		ReturnButton.setActionCommand("メインへ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("予約変更");
		lblNewLabel.setBounds(36, 31, 143, 13);
		add(lblNewLabel);

		customerid = new JTextField();
		customerid.setBounds(131, 54, 113, 19);
		add(customerid);
		customerid.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("顧客番号");
		lblNewLabel_1.setBounds(63, 54, 56, 13);
		add(lblNewLabel_1);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(33, 106, 485, 83);
		add(scrollPane);


		JLabel lblNewLabel_3 = new JLabel("施術時間合計");
		lblNewLabel_3.setBounds(255, 293, 78, 13);
		add(lblNewLabel_3);


		String[] bookColumnNames = {"予約番号","日付","開始時間","担当者","顧客名","メニュー","メニュー2"};
		Object[][] bookData = {};
		DefaultTableModel model = new DefaultTableModel(bookData,bookColumnNames);
		JTable table = new JTable(model);
		scrollPane.setViewportView(table);

		JButton btnNewButton = new JButton("検索");

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(customerid.getText().isBlank()) {
					dialog("入力エラー","顧客番号を入力してください");
				}else {
					
					
					ArrayList<M_customer> mclist =new  ArrayList<>();
					AccessDB.getInstance().connect();
					mclist = AccessDB.getInstance().getM_customerList();
					AccessDB.getInstance().disconnect();
					int count = 0;
					for(M_customer m : mclist) {
						if(Integer.parseInt(customerid.getText())==m.getCustomerid()) {
							count++;
						}
					}
					if(count==0) {
						dialog("入力エラー","存在しない顧客番号です");
					}else {
					ArrayList<M_reservation> list = new ArrayList<>();
					model.setRowCount(0);
					AccessDB.getInstance().connect();
					list = AccessDB.getInstance().getReservationList(Integer.parseInt(customerid.getText()));
					AccessDB.getInstance().disconnect();
					if(list.size()>0) {
						for(M_reservation m : list) {
							String starttime = "";
							switch (m.getStarttime()) {
							case 1:starttime = "9:00";break;
							case 2:starttime = "10:00";break;
							case 3:starttime = "11:00";break;
							case 4:starttime = "12:00";break;
							case 5:starttime = "13:00";break;
							case 6:starttime = "14:00";break;
							case 7:starttime = "15:00";break;
							case 8:starttime = "16:00";break;
							case 9:starttime = "17:00";break;
							case 10:starttime = "18:00";break;
							}
							Object[] o = {m.getId(),m.getHiduke(),starttime,m.getStaffname(),m.getCustomername(),m.getMenuname1(),m.getMenuname2()};
							model.addRow(o);
						}
					}else {
						dialog("予約内容確認","予約がありません");
					}
				}
				}
			}
		});	

		btnNewButton.setBounds(411, 53, 91, 21);
		add(btnNewButton);

		JLabel lblNewLabel_1_1 = new JLabel("予約情報");
		lblNewLabel_1_1.setBounds(24, 83, 155, 13);
		add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_1_1 = new JLabel("変更情報");
		lblNewLabel_1_1_1.setBounds(24, 199, 155, 13);
		add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("日付");
		lblNewLabel_1_2.setBounds(36, 258, 56, 13);
		add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_2_1 = new JLabel("開始時間");
		lblNewLabel_1_2_1.setBounds(36, 405, 56, 13);
		add(lblNewLabel_1_2_1);

		JLabel lblNewLabel_1_2_1_1 = new JLabel("メニュー");
		lblNewLabel_1_2_1_1.setBounds(226, 222, 56, 13);
		add(lblNewLabel_1_2_1_1);

		JLabel lblNewLabel_1_2_1_1_1 = new JLabel("担当者");
		lblNewLabel_1_2_1_1_1.setBounds(36, 293, 56, 13);
		add(lblNewLabel_1_2_1_1_1);

		JLabel lblNewLabel_2 = new JLabel("予約番号");
		lblNewLabel_2.setBounds(36, 222, 50, 13);
		add(lblNewLabel_2);

		//施術合計時間表示パネル
		JTextPane textPane = new JTextPane();
		textPane.setBounds(333, 289, 39, 21);
		add(textPane);

		//単位
		JLabel lblNewLabel_6 = new JLabel("時間");
		lblNewLabel_6.setBounds(384, 293, 66, 13);
		add(lblNewLabel_6);

		id = new JTextField();
		id.setBounds(98, 219, 116, 19);
		add(id);
		id.setColumns(10);
		Object[][] bookData2 = {};

		DefaultTableModel model2 = new DefaultTableModel(bookData2,bookColumnNames);

		//日付を選ぶコンボボックス
		JComboBox<LocalDate> day = new JComboBox<>();

		LocalDate today = LocalDate.now();
		LocalDate tomorrow = today.plusDays(1);
		LocalDate futukago = today.plusDays(2);
		LocalDate mikkago = today.plusDays(3);
		LocalDate yokkkago = today.plusDays(4);
		LocalDate itukago = today.plusDays(5);
		LocalDate muikago = today.plusDays(6);

		LocalDate[] days = {today,tomorrow,futukago,mikkago,yokkkago,itukago,muikago};

		for(int i = 0; i < days.length;i++) {
			day.addItem(days[i]);
		}
		day.setBounds(104, 254, 116, 20);
		add(day);

		//スタッフを選ぶコンボボックス
		JComboBox<String> staff = new JComboBox<>();
		staff.setBounds(104, 289, 113, 21);
		add(staff);	

		AccessDB.getInstance().connect();
		stafflist = AccessDB.getInstance().getM_staffList();
		AccessDB.getInstance().disconnect();
		for(M_staff m :stafflist) {
			staff.addItem(m.getStaffname());
		}
		//メニューを選ぶコンボボックス
		JComboBox<String> menu1 = new JComboBox<>();
		menu1.setBounds(296, 218, 114, 21);
		add(menu1);

		JComboBox<String> menu2 = new JComboBox<>();
		menu2.setBounds(296, 254, 114, 21);
		add(menu2);

		AccessDB.getInstance().connect();
		menulist = AccessDB.getInstance().getM_menuList();
		AccessDB.getInstance().disconnect();
		for(M_menu m :menulist) {
			menu1.addItem(m.getMenuname());
			menu2.addItem(m.getMenuname());
		}
		//時間を選ぶコンボボックス
		JComboBox<String> time = new JComboBox<>();
		time.setBounds(104, 401, 116, 21);
		add(time);		
		JButton sarch = new JButton("時間検索");
		sarch.setBounds(226, 346, 91, 21);
		add(sarch);
		sarch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				time.removeAllItems();

				//コンボボックスで選んだメニューの合計所要時間を計算
				AccessDB.getInstance().connect();
				menulist = AccessDB.getInstance().getM_menuList();

				AccessDB.getInstance().disconnect();
				int sumtime =0;
				for(M_menu m :menulist) {
					if(menu1.getSelectedItem().equals(m.getMenuname())) {
						sumtime += m.getMenutime();
					}
					if(menu2.getSelectedItem().equals(m.getMenuname())) {
						sumtime += m.getMenutime();
					}
				}
				if(sumtime==0) {
					dialog("選択エラー","メニューを選択してください");
				}else if(menu1.getSelectedItem().equals(menu2.getSelectedItem())){
					dialog("選択エラー","同じメニューが選択されています");
				}
				else {
					textPane.setText(Integer.toString(sumtime));
					//日付、担当、所要時間を満たす予約可能時間をコンボボックスに入れる
					//時間変換
					LocalDate lo = (LocalDate)day.getSelectedItem();
					DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					String ss = lo.format(fmt);
					SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
					Date date = new Date();
					try {
						date = f.parse(ss);
					}catch(ParseException e1) {
						e1.printStackTrace();
					}

					//コンボボックスで選んだスタッフ名をスタッフ番号に変換
					AccessDB.getInstance().connect();
					stafflist = AccessDB.getInstance().getM_staffList();
					AccessDB.getInstance().disconnect();
					int Staffid = 0;
					for(M_staff m :stafflist) {
						if(staff.getSelectedItem().equals(m.getStaffname())) {
							Staffid = m.getStaffid();
						}
					}
					//空いている時間をコンボボックスに追加
					ArrayList<Integer> list2 = new ArrayList<>();
					AccessDB.getInstance().connect();
					list2 = AccessDB.getInstance().getDate(Staffid, date, sumtime);
					AccessDB.getInstance().disconnect();
					System.out.println("所要時間"+sumtime);

					for(int i = 0; i < list2.size(); i++) {
						switch (list2.get(i)) {
						case 1:time.addItem("9:00");break;
						case 2:time.addItem("10:00");break;
						case 3:time.addItem("11:00");break;
						case 4:time.addItem("12:00");break;
						case 5:time.addItem("13:00");break;
						case 6:time.addItem("14:00");break;
						case 7:time.addItem("15:00");break;
						case 8:time.addItem("16:00");break;
						case 9:time.addItem("17:00");break;
						case 10:time.addItem("18:00");break;
						}
					}
				}
			}
		});

		JButton btnNewButton_1 = new JButton("予約変更");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(id.getText().isBlank()) {
					dialog("入力エラー","予約番号を入力してください");
				}
				else {
					int ret = JOptionPane.showConfirmDialog(null, "本当に変更しますか？", "変更確認", JOptionPane.YES_NO_OPTION , JOptionPane.WARNING_MESSAGE);

					switch(ret) {
					case JOptionPane.YES_OPTION:
						int Staffid = 0;
						int Menuid1 = 0;
						int Menuid2 = 0;

						//コンボボックスで選んだスタッフ名をスタッフ番号に変換
						AccessDB.getInstance().connect();
						stafflist = AccessDB.getInstance().getM_staffList();
						AccessDB.getInstance().disconnect();
						for(M_staff m :stafflist) {
							if(staff.getSelectedItem().equals(m.getStaffname())) {
								Staffid = m.getStaffid();
							}
						}
						//コンボボックスで選んだメニュー名をメニュー番号に変換
						AccessDB.getInstance().connect();
						menulist = AccessDB.getInstance().getM_menuList();
						AccessDB.getInstance().disconnect();
						for(M_menu m :menulist) {
							if(menu1.getSelectedItem().equals(m.getMenuname())) {
								Menuid1 = m.getMenuid();
							}
						}
						for(M_menu m :menulist) {
							if(menu2.getSelectedItem().equals(m.getMenuname())) {
								Menuid2 = m.getMenuid();
							}
						}
						//コンボボックスで選んだ日付を変換
						LocalDate lo = (LocalDate)day.getSelectedItem();
						DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						String ss = lo.format(fmt);
						SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
						Date date = new Date();
						try {
							date = f.parse(ss);
						}catch(ParseException e1) {
							e1.printStackTrace();
						}
						//予約時間(int starttime)
						String str = (String)time.getSelectedItem();
						int starttime = 0;
						switch (str) {
						case "9:00":starttime = 1;break; 
						case "10:00":starttime = 2;break; 
						case "11:00":starttime = 3;break; 
						case "12:00":starttime = 4;break; 
						case "13:00":starttime = 5;break; 
						case "14:00":starttime = 6;break; 
						case "15:00":starttime = 7;break; 
						case "16:00":starttime = 8;break; 
						case "17:00":starttime = 9;break; 
						case "18:00":starttime = 10;break;
						}

						AccessDB.getInstance().connect();
						int x = AccessDB.getInstance().updateM_book(Integer.parseInt(id.getText()), date, starttime, Staffid, Menuid1, Menuid2);
						AccessDB.getInstance().disconnect();
						if(x == 0) {
							dialog("変更エラー","変更できませんでした");
						}else {					
							model.setRowCount(0);
							ArrayList<M_reservation> list = new ArrayList<>();
							AccessDB.getInstance().connect();
							list = AccessDB.getInstance().getReservationList(Integer.parseInt(customerid.getText()));
							AccessDB.getInstance().disconnect();
							for(M_reservation m : list) {
								String starttime2 = "";
								switch (m.getStarttime()) {
								case 1:starttime2 = "9:00";break;
								case 2:starttime2 = "10:00";break;
								case 3:starttime2 = "11:00";break;
								case 4:starttime2 = "12:00";break;
								case 5:starttime2 = "13:00";break;
								case 6:starttime2 = "14:00";break;
								case 7:starttime2 = "15:00";break;
								case 8:starttime2 = "16:00";break;
								case 9:starttime2 = "17:00";break;
								case 10:starttime2 = "18:00";break;
								}			
								Object[] o = {m.getId(),m.getHiduke(),starttime2,m.getStaffname(),m.getCustomername(),m.getMenuname1(),m.getMenuname2()};
								model.addRow(o);
								
								dialog("変更確認","変更しました");
								id.setText("");
							}
						}
						
						break;
					case JOptionPane.NO_OPTION:
						dialog("変更確認","変更を取りやめました");
					}
				}
			}
		});	
		btnNewButton_1.setBounds(368, 401, 91, 21);
		add(btnNewButton_1);
	}

	public void dialog(String messege1,String messege2) {

		JDialog d = new JDialog();
		d.setTitle(messege1);
		d.setSize(300, 200);
		d.setLocationRelativeTo(null);
		d.setModal(true);

		JLabel messageLabel = new JLabel(messege2);
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		JButton dialogButton = new JButton("OK");
		dialogButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.dispose(); // Close the dialog
			}
		});
		d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		d.setVisible(true);	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("メインへ")) {
			Main.card.show(Main.CardLayoutPanel, "メインパネル");
		}		
	}
}
