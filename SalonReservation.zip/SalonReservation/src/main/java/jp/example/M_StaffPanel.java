package jp.example;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class M_StaffPanel extends JPanel implements ActionListener{
	private JTextField textField;
	private JTextField textField_1;
	Object[][] ob;
	String[] koumoku = {"スタッフID","氏名"};

	/**
	 * Create the panel.
	 */
	public M_StaffPanel() {
		setBounds(0, 0, 562, 529);//パネルサイズ
		setLayout(null);//絶対レイアウト

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(463, 481, 73, 21);
		ReturnButton.addActionListener(this);
		ReturnButton.setActionCommand("店長へ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("スタッフ新規登録");
		lblNewLabel.setBounds(39, 292, 143, 13);
		add(lblNewLabel);
				
		//スクロールパネル		
		final DefaultTableModel model = new DefaultTableModel(ob,koumoku);
		JTable table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(90, 100, 377, 165);
		add(scrollPane);
		
		JButton btnNewButton = new JButton("一覧表示");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.setRowCount(0);
				ArrayList<M_staff> list = new ArrayList<>();
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_staffList();
				AccessDB.getInstance().disconnect();
				for(M_staff m : list) {
					Object[] o = {m.getStaffid(),m.getStaffname()};
					model.addRow(o);
				}
			}
		});
		btnNewButton.setBounds(231, 62, 91, 21);
		add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(152, 421, 143, 19);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(152, 327, 214, 19);
		add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("スタッフID");
		lblNewLabel_1.setBounds(39, 424, 66, 13);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("氏名");
		lblNewLabel_1_1.setBounds(39, 330, 50, 13);
		add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("スタッフ管理パネル");
		lblNewLabel_2.setBounds(12, 31, 143, 13);
		add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("新規登録");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ArrayList<M_staff> list = new ArrayList<>();
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_staffList();
				AccessDB.getInstance().disconnect();
				int max = 0;
				for(M_staff i : list){
					if(i.getStaffid() > max) {
						max = i.getStaffid();
					}
				}
				max++;
							
		//		int staffid = Integer.parseInt(textField.getText());
				String staffname = textField_1.getText();
				
				AccessDB.getInstance().connect();
				AccessDB.getInstance().insertM_staff(max, staffname);
				AccessDB.getInstance().disconnect();
				
				//JDialogのインスタンスを作る
				JDialog d = new JDialog();
				//ダイアログにタイトルをつける
				d.setTitle("スタッフ新規登録");
				//ダイアログのサイズを指定する
				d.setSize(300, 200);
				//ダイアログの表示場所。Nullなら画面中央。
				d.setLocationRelativeTo(null);
				// ダイアログをモーダルダイアログとして設定
				// モーダルの時は他のウインドウとかの操作をブロックできる
				d.setModal(true);
				
				JLabel messageLabel = new JLabel("登録しました");
				messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
				d.getContentPane().add(messageLabel, BorderLayout.CENTER);

				// ダイアログにコンポーネントを追加
//				// ダイアログにテキストフィールドを追加
//				JTextField textField = new JTextField();
//				d.getContentPane().add(textField, BorderLayout.NORTH);
				// ダイアログにボタンを追加
				JButton dialogButton = new JButton("OK");
				
				
				dialogButton.addActionListener(new ActionListener() {
				    public void actionPerformed(ActionEvent e) {
				        d.dispose(); // Close the dialog
				    }
				});
				d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
				// ダイアログの表示
				d.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(412, 326, 91, 21);
		add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("削除");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int staffid = Integer.parseInt(textField.getText());
				
				AccessDB.getInstance().connect();
				AccessDB.getInstance().staffDelete(staffid);
				AccessDB.getInstance().disconnect();
				
				//JDialogのインスタンスを作る
				JDialog d = new JDialog();
				//ダイアログにタイトルをつける
				d.setTitle("スタッフ削除");
				//ダイアログのサイズを指定する
				d.setSize(300, 200);
				//ダイアログの表示場所。Nullなら画面中央。
				d.setLocationRelativeTo(null);
				// ダイアログをモーダルダイアログとして設定
				// モーダルの時は他のウインドウとかの操作をブロックできる
				d.setModal(true);
				
				JLabel messageLabel = new JLabel("削除しました");
				messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
				d.getContentPane().add(messageLabel, BorderLayout.CENTER);

				// ダイアログにコンポーネントを追加
//				// ダイアログにテキストフィールドを追加
//				JTextField textField = new JTextField();
//				d.getContentPane().add(textField, BorderLayout.NORTH);
				// ダイアログにボタンを追加
				JButton dialogButton = new JButton("OK");
				
				
				dialogButton.addActionListener(new ActionListener() {
				    public void actionPerformed(ActionEvent e) {
				        d.dispose(); // Close the dialog
				    }
				});
				d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
				// ダイアログの表示
				d.setVisible(true);
			}
		});
		btnNewButton_1_1.setBounds(412, 420, 91, 21);
		add(btnNewButton_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("削除");
		lblNewLabel_3.setBounds(39, 398, 143, 13);
		add(lblNewLabel_3);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("店長へ")) {
			Main.card.show(Main.CardLayoutPanel, "店長パネル");
		}		
	}
}
