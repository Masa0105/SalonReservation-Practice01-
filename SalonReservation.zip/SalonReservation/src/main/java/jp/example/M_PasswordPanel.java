package jp.example;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class M_PasswordPanel extends JPanel implements ActionListener{
	private JTextField password;
	private JTextField newpassword;
	String pass;
	String newpass;

	/**
	 * Create the panel.
	 */
	public M_PasswordPanel() {
		setBounds(0, 0, 562, 529);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("現在のパスワード");
		lblNewLabel.setBounds(94, 166, 114, 13);
		add(lblNewLabel);
		
		password = new JTextField();
		password.setBounds(257, 163, 96, 19);
		add(password);
		password.setColumns(10);
		
		newpassword = new JTextField();
		newpassword.setBounds(257, 262, 96, 19);
		add(newpassword);
		newpassword.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("新しいパスワード");
		lblNewLabel_1.setBounds(94, 265, 103, 13);
		add(lblNewLabel_1);
		
		
		
		JButton change = new JButton("パスワードを変更");
		change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(password.getText().isBlank() || newpassword.getText().isBlank()) {
					dialog("入力エラー","パスワードを入力してください");
				}else {
					if(password.getText().equals(pass)) {
						newpass = newpassword.getText();
						dialog("入力エラー","パスワードを入力してください");
					}
				}
			}
		});
		change.setBounds(221, 386, 146, 21);
		add(change);

		
		
		
		
		
	}
	public void dialog(String messege1,String messege2) {

		JDialog d = new JDialog();
		d.setTitle(messege1);
		d.setSize(300, 200);
		d.setLocationRelativeTo(null);
		d.setModal(true);

		JLabel messageLabel = new JLabel(messege2);
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		JButton dialogButton = new JButton("OK");
		dialogButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.dispose(); // Close the dialog
			}
		});
		d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		d.setVisible(true);	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("店長へ")) {
			Main.card.show(Main.CardLayoutPanel, "店長パネル");
		}		
	}
}
