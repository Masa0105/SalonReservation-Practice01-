package jp.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;


public class AccessDB {
	private static AccessDB instance;
	private Connection con;
	private String url;
	private String user;
	private String password;

	public AccessDB(){
		url = "jdbc:postgresql://localhost:5432/postgres" ;
		user = "postgres" ;
		password = "postgrestest" ;	

		//同一クラス
		connect();
		setup();
		disconnect();
	}


	public static synchronized AccessDB getInstance() {
		if(instance == null) {
			instance = new AccessDB();
		}
		return instance;	
	}

	public void connect() {
		try {
			con = DriverManager.getConnection ( url, user, password ); 
			//con.setAutoCommit(false);
		} catch ( SQLException e ) {
			e.printStackTrace() ;
		}
	}

	public void disconnect() {

		if(con != null)
			try {con.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
	}

	public void setup() {

		//SQL文（テーブルがなければ作成）
		String booktable = "CREATE TABLE IF NOT EXISTS booktable (id SERIAL NOT NULL PRIMARY KEY,hiduke DATE,starttime INTEGER,staffid INTEGER,customerid INTEGER,menuid1 INTEGER,menuid2 INTEGER);";
		String stafftable = "CREATE TABLE IF NOT EXISTS stafftable(staffid INTEGER NOT NULL PRIMARY KEY,staffname VARCHAR);";
		String customertable = "CREATE TABLE IF NOT EXISTS customertable(customerid INTEGER NOT NULL PRIMARY KEY,customername VARCHAR,tel VARCHAR,email VARCHAR);";
		String menutable = "CREATE TABLE IF NOT EXISTS menutable(menuid INTEGER NOT NULL PRIMARY KEY,menuname VARCHAR,menutime VARCHAR,price VARCHAR);";

		//SQLへ実行指示
		try (Statement stmt = con.createStatement()) {
			stmt.executeUpdate(booktable);
			stmt.executeUpdate(stafftable);
			stmt.executeUpdate(customertable);
			stmt.executeUpdate(menutable);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//予約台帳検索（顧客番号を指定して検索）
	public ArrayList<M_reservation> getReservationList(int customerid) {
		ArrayList<M_reservation> list = new ArrayList<>();

		//各IDは表示しない。
		String sql = "SELECT id,hiduke,starttime,stafftable.staffname,customertable.customername,m1.menuname,m1.price,m2.menuname, m2.price FROM booktable"
				+ " JOIN stafftable ON booktable.staffid = stafftable.staffid"
				+ " JOIN customertable ON booktable.customerid = customertable.customerid"
				+ " JOIN menutable AS m1 ON booktable.menuid1 = m1.menuid"
				+ " JOIN menutable AS m2 ON booktable.menuid2 = m2.menuid"
				+ " WHERE booktable.customerid = "+customerid;

		try (Statement pstmt = con.createStatement(); 
				ResultSet result = pstmt.executeQuery(sql)){	

			while(result.next()) {//実行結果の取得
				int id = result.getInt(1);
				Date hiduke = result.getDate(2);
				int starttime = result.getInt(3);
				String staffname = result.getString(4);
				String customername = result.getString(5);
				String menuname1 = result.getString(6);
				int price1 = result.getInt(7);
				String menuname2 = result.getString(8);
				int price2 = result.getInt(9);

				list.add(new M_reservation(id,(java.sql.Date) hiduke,starttime,staffname,customername,menuname1,price1, menuname2, price2));				
			}
		} catch ( SQLException e ) {
			e.printStackTrace() ;
		}
		return list;
	}

	//予約台帳検索（スタッフ番号を指定して検索）
	public ArrayList<M_reservation> getReservationList2(int staffid) {
		ArrayList<M_reservation> list = new ArrayList<>();

		//各IDは表示しない。
		String sql = "SELECT id,hiduke,starttime,stafftable.staffname,customertable.customername,m1.menuname,m1.price,m2.menuname, m2.price FROM booktable"
				+ " JOIN stafftable ON booktable.staffid = stafftable.staffid"
				+ " JOIN customertable ON booktable.customerid = customertable.customerid"
				+ " JOIN menutable AS m1 ON booktable.menuid1 = m1.menuid"
				+ " JOIN menutable AS m2 ON booktable.menuid2 = m2.menuid"
				+ " WHERE booktable.staffid = "+staffid;

		try (Statement pstmt = con.createStatement(); 
				ResultSet result = pstmt.executeQuery(sql)){	

			while(result.next()) {//実行結果の取得
				int id = result.getInt(1);
				Date hiduke = result.getDate(2);
				int starttime = result.getInt(3);
				String staffname = result.getString(4);
				String customername = result.getString(5);
				String menuname1 = result.getString(6);
				int price1 = result.getInt(7);
				String menuname2 = result.getString(8);
				int price2 = result.getInt(9);

				list.add(new M_reservation(id,(java.sql.Date) hiduke,starttime,staffname,customername,menuname1,price1, menuname2, price2));				
			}
		} catch ( SQLException e ) {
			e.printStackTrace() ;
		}
		return list;
	}

	//INSERT(追加)

	//	insertM_ reservation（新しい予約を追加）
	public int insertM_reservation(int id,Date date,int starttime,int staffid,int customerid,int menuid1,int menuid2) {
		int count =0;
		String sql ="INSERT INTO booktable VALUES (?,?,?,?,?,?,?)";
		try (PreparedStatement pstmt = con.prepareStatement(sql); ) {
			Timestamp date1 = new Timestamp(date.getTime());

			pstmt.setInt(1, id);
			pstmt.setTimestamp(2, date1);
			//pstmt.setDate(2, m_reservation.getHiduke());
			pstmt.setInt(3, starttime);
			pstmt.setInt(4, staffid);
			pstmt.setInt(5, customerid);
			pstmt.setInt(6, menuid1);
			pstmt.setInt(7, menuid2);

			count = pstmt.executeUpdate();	

		} catch ( SQLException e ) {
			e.printStackTrace() ;
		}
		return count;
	}

	//	insertM_ customer（顧客を追加）
	public int insertM_customer(int customerid,String customername,String tel,String email) {

		int count =0;
		String sql ="INSERT INTO customertable VALUES (?,?,?,?)";
		try (PreparedStatement pstmt = con.prepareStatement(sql); ) {
			pstmt.setInt(1, customerid);
			pstmt.setString(2, customername);
			pstmt.setString(3, tel);
			pstmt.setString(4, email);

			count = pstmt.executeUpdate();	

		} catch ( SQLException e ) {
			e.printStackTrace() ;
		}
		return count;
	}

	//	insertM_ staff（従業員を追加）	
	public int insertM_staff(int staffid,String staffname) {
		int count =0;
		String sql ="INSERT INTO stafftable VALUES (?,?)";
		try (PreparedStatement pstmt = con.prepareStatement(sql); ) {
			pstmt.setInt(1, staffid);
			pstmt.setString(2, staffname);

			count = pstmt.executeUpdate();	

		} catch ( SQLException e ) {
			e.printStackTrace() ;
		}
		return count;
	}

	//	insertM_ menu（メニューを追加）
	public int insertM_menu(int menuid,String menuname ,int time,int menuprice) {
		int count =0;
		String sql ="INSERT INTO menutable VALUES (?,?,?,?)";
		try (PreparedStatement pstmt = con.prepareStatement(sql); ) {
			pstmt.setInt(1, menuid);
			pstmt.setString(2, menuname);
			pstmt.setInt(3, time);
			pstmt.setInt(4, menuprice);

			count = pstmt.executeUpdate();	

		} catch ( SQLException e ) {
			e.printStackTrace() ;
		}
		return count;
	}

	//UPDATE(更新)
	//顧客を更新
	public int updateM_customer(int customerid,String customername,String tel,String email) {

		String sql = "update customertable set customername = ? ,tel= ?,email= ?  Where customerid =" + customerid;
		int count = 0;

		try(PreparedStatement stmt = con.prepareStatement(sql);){
			stmt.setString(1, customername);
			stmt.setString(2, tel);
			stmt.setString(3, email);

			count = stmt.executeUpdate();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	//予約内容更新
	public int updateM_book(int id,Date hiduke, int starttime,int employeeid,int menuid1,int menuid2) {
		int count = 0;

		String sql = "update booktable set hiduke = ?,starttime = ? ,staffid = ? ,menuid1= ?, menuid2= ? Where id =" + id;

		try(PreparedStatement stmt = con.prepareStatement(sql);){
			stmt.setDate(1, new java.sql.Date (hiduke.getTime()));
			stmt.setInt(2, starttime);
			stmt.setInt(3, employeeid);
			stmt.setInt(4, menuid1);
			stmt.setInt(5, menuid2);

			count = stmt.executeUpdate();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	//従業員を更新
	public int updateM_staff(int employyid,String employyname) {
		int count = 0;
		String sql = "update stafftable set employyname = ? Where employyid =" + employyid;

		try(PreparedStatement stmt = con.prepareStatement(sql);){
			stmt.setString(1,employyname);

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	//3.	getBooktableインスタンスメソッドを作成する（予約情報全件取得）
	public ArrayList<M_reservation> getAllList(){
		ArrayList<M_reservation> list = new ArrayList<>();
		String sql ="SELECT id,hiduke,starttime,stafftable.staffname,customertable.customername,m1.menuname,m1.price,m2.menuname, m2.price FROM booktable"
				+ " JOIN stafftable ON booktable.staffid = stafftable.staffid"
				+ " JOIN customertable ON booktable.customerid = customertable.customerid"
				+ " JOIN menutable AS m1 ON booktable.menuid1 = m1.menuid"
				+ " JOIN menutable AS m2 ON booktable.menuid2 = m2.menuid";

		try(PreparedStatement pstmt = con.prepareStatement(sql); ){
			ResultSet result = pstmt.executeQuery();	

			while(result.next()) {//実行結果の取得
				int id = result.getInt(1);
				Date hiduke = result.getDate(2);
				int starttime = result.getInt(3);
				String staffname = result.getString(4);
				String customername = result.getString(5);
				String menuname1 = result.getString(6);
				int price1 = result.getInt(7);
				String menuname2 = result.getString(8);
				int price2 = result.getInt(9);

				list.add(new M_reservation(id,(java.sql.Date) hiduke,starttime,staffname,customername,menuname1,price1,menuname2,price2));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}	
		return list;
	}


	//6.	deleteBooktableインスタンスメソッドを作成する（予約情報から削除）
	public int deleteList(int id) {
		int count = 0;

		String sql = "delete  from booktable where id =" + id;
		try(PreparedStatement pstmt = con.prepareStatement(sql); ){
			count = pstmt.executeUpdate();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	//顧客情報全件取得
	public ArrayList<M_customer> getM_customerList(){
		ArrayList<M_customer> list = new ArrayList<>();
		String sql = "select * from customertable";

		try(Statement stmt = con.createStatement();
				ResultSet result = stmt.executeQuery(sql)){

			while ( result.next() ) {
				M_customer m_customer = new M_customer();
				m_customer.setCustomerid(result.getInt(1));
				m_customer.setCustomername(result.getString(2));
				m_customer.setTel(result.getString(3));
				m_customer.setEmail(result.getString (4));
				list.add(m_customer);
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	//顧客情報1件取得
	public M_customer getM_customer(int customerid){
		M_customer m_customer = new M_customer();
		String sql = "select * from customertable WHERE customerid = "+ customerid;

		try(Statement stmt = con.createStatement();
				ResultSet result = stmt.executeQuery(sql)){

			while ( result.next() ) {
				m_customer.setCustomerid(result.getInt(1));
				m_customer.setCustomername(result.getString(2));
				m_customer.setTel(result.getString(3));
				m_customer.setEmail(result.getString (4));
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return m_customer;
	}

	//顧客情報削除
	public int deleteFromCustomerList(int id) {
		int count = 0;

		String sql = "delete  from customertable where customerid =" + id;
		try(PreparedStatement pstmt = con.prepareStatement(sql); ){
			count = pstmt.executeUpdate();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}


	//メニュー情報全件取得(邉見変更分・time、price追加)
	public ArrayList<M_menu> getM_menuList(){
		ArrayList<M_menu> list = new ArrayList<>();
		String sql = "select * from menutable";

		try(Statement stmt = con.createStatement();
				ResultSet result = stmt.executeQuery(sql)){

			while ( result.next() ) {
				M_menu m_menu = new M_menu();
				m_menu.setMenuid(result.getInt(1));
				m_menu.setMenuname(result.getString(2));
				m_menu.setMenutime(result.getInt(3));
				m_menu.setPrice(result.getInt(4));

				list.add(m_menu);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return list;
	}


	//メニューを更新(邉見変更分・menutime,price追加)
	public int updateM_menu(int memuid,String memuname,int menutime,int price) {
		int count = 0;
		String sql = "update menutable set memuname = ?,memutime = ?,price = ? Where memuid =" + memuid;
		try(PreparedStatement stmt = con.prepareStatement(sql);){                          
			stmt.setString(1, memuname);
			stmt.setInt(2, menutime);
			stmt.setInt(3, price);
			count = stmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	//スタッフ情報全件取得（増田追加分）
	public ArrayList<M_staff> getM_staffList(){
		ArrayList<M_staff> mslist = new ArrayList<>();
		String sql = "select * from stafftable";

		try(Statement stmt = con.createStatement();
				ResultSet result = stmt.executeQuery(sql)){

			while ( result.next() ) {
				M_staff ms = new M_staff();
				//スタッフid
				ms.setStaffid(result.getInt(1));
				//氏名
				ms.setStaffname(result.getString(2));

				mslist.add(ms);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return mslist;		
	}

	//スタッフ削除（増田追加分）
	public int staffDelete(int id) {
		int count = 0;

		String sql = "delete  from stafftable where staffid =" + id;
		try(PreparedStatement pstmt = con.prepareStatement(sql); ){
			count = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}

	//顧客が入力した情報をもとに、空いている時間を引っ張ってくるメソッド(八木追加分)
	public ArrayList<Integer> getDate(int nameNum,Date date,int menuTime){				
		//DBからの数値を格納するリスト
		ArrayList<Integer> list = new ArrayList<>();
		//空きの時間枠を格納するリスト
		ArrayList<Integer> list2 = new ArrayList<>();
		//施術合計値から選択できる時間を格納するリスト
		ArrayList<Integer> list3 = new ArrayList<>();

		java.sql.Date d = new java.sql.Date(date.getTime());

		String sql = "SELECT starttime FROM booktable where staffid =" + nameNum + " and hiduke = '" + d + "'";

		try(Statement stmt = con.createStatement();
				ResultSet result = stmt.executeQuery(sql)){	
			while(result.next()) {//実行結果の取得	
				list.add(result.getInt(1));	
			}
			System.out.println(list);

			//空いている予約枠をlist2に格納する
			for(int i = 1; i <= 10; i++) {
				if(list.contains(i)) {
					continue;
				}
				list2.add(i);
			}
			System.out.println(list2);

		}catch(SQLException e) {
			e.printStackTrace();
		}

		int count = 0;
		int y = 0;

		//引数の施術合計値をもとに選択できる時間をlist3に格納
		if(menuTime == 1) {
			for(int i =0;i<list2.size();i++){
				list3.add(i, list2.get(i));
			}
		}else {
			for(int i = 0; i < list2.size(); i++) {
				if(list2.get(i) == y+1) {
					count++;
					y = list2.get(i);
					if(count >= menuTime) {
						list3.add( y - (menuTime - 1));
					}
				}else {
					count = 1;
					y = list2.get(i);
				}
			}
		}
		System.out.println(list3);
		return list3;				
	}

	//メニュー削除（増田追加分）
	public int menuDelete(int id) {
		int count = 0;

		String sql = "delete  from menutable where menuid =" + id;
		try(PreparedStatement pstmt = con.prepareStatement(sql); ){
			count = pstmt.executeUpdate();

		}catch(SQLException e) {
			e.printStackTrace();
		}
		return count;
	}
	

	//	//	getPeriodList（予約台帳の検索機能（日付は指定させる））
	//	public ArrayList<M_reservation> getPeriodList(Date start,Date end,String key,String word) {
	//		ArrayList<M_reservation> list = new ArrayList<>();
	//
	//		//各IDは表示しない。key=列名、word=検索したい名前、日付、start=検索したい期間の始まり、end=検索したい期間のおわり
	//		String sql = "SELECT id,hiduke,starttime,stafftable.staffname,customertable.customername,menutable.menuname,menutable.price"
	//				+ " FROM booktable JOIN stafftable ON booktable.staffid = stafftable.staffid"
	//				+ " JOIN customertable ON booktable.customerid = customertable.customerid"
	//				+ " JOIN menutable ON booktable.menuid = menutable.menuid"
	//				+ " WHERE "+key+"='"+word+"'AND hiduke BETWEEN '"+start+"' AND '"+end+"'ORDER BY hiduke";
	//
	//		try (Statement pstmt = con.createStatement(); 
	//				ResultSet result = pstmt.executeQuery(sql)){	
	//
	//			while(result.next()) {//実行結果の取得
	//				int id = result.getInt(1);
	//				Date hiduke = result.getDate(2);
	//				int starttime = result.getInt(3);
	//				String staffname = result.getString(4);
	//				String customername = result.getString(5);
	//				String menuname = result.getString(6);
	//
	//				list.add(new M_reservation(id,(java.sql.Date) hiduke,starttime,staffname,customername,menuname));				
	//			}
	//		} catch ( SQLException e ) {
	//			e.printStackTrace() ;
	//		}
	//		return list;
	//	}

	//	
	//	//メニュー情報全件取得
	//	public ArrayList<M_menu> getM_menuList(){
	//		ArrayList<M_menu> list = new ArrayList<>();
	//		String sql = "select * from menutable";
	//
	//		try(Statement stmt = con.createStatement();
	//				ResultSet result = stmt.executeQuery(sql)){
	//
	//			while ( result.next() ) {
	//				M_menu m_menu = new M_menu();
	//				m_menu.setMenuid(result.getInt(1));
	//				m_menu.setMenuname(result.getString(2));
	//
	//				list.add(m_menu);
	//			}
	//		}catch(SQLException e) {
	//			e.printStackTrace();
	//		}
	//		return list;
	//	}

	//	//メニューを更新
	//	public int updateM_menu(int memuid,String memuname) {
	//		int count = 0;
	//
	//		String sql = "update menutable set memuname = ? Where memuid =" + memuid;
	//
	//		try(PreparedStatement stmt = con.prepareStatement(sql);){                          
	//			stmt.setString(1, memuname);
	//
	//			count = stmt.executeUpdate();
	//
	//		}catch(SQLException e) {
	//			e.printStackTrace();
	//		}
	//		return count;
	//	}

	//	//メニュー全件取得（やぎ変更済み）
	//	public ArrayList<M_menu> getM_menu() {
	//		ArrayList<M_menu> list = new ArrayList<>();
	//		String sql ="select * from menutable";
	//		try (Statement pstmt = con.createStatement(); 
	//				ResultSet result = pstmt.executeQuery(sql)) {
	//
	//			while(result.next()) {//実行結果の取得
	//				M_menu menu = new M_menu();
	//				menu.setMenuid(result.getInt(1));
	//				menu.setMenuname(result.getString(2));
	//				menu.setPrice(result.getInt(3));
	//				menu.setPrice(result.getInt(4));
	//
	//				list.add(menu);
	//			}
	//
	//		} catch ( SQLException e ) {
	//			e.printStackTrace() ;
	//		}
	//		return list;
	//	}



	//	//メニューを更新(yagi変更済み)
	//	public int updateM_menu(int memuid,String memuname,int price) {
	//		int count = 0;
	//
	//		String sql = "update menutable set menuname = ?,price = ? Where menuid =" + memuid;
	//
	//		try(PreparedStatement stmt = con.prepareStatement(sql); ){                          
	//			stmt.setString(1, memuname);
	//			stmt.setInt(2, price);
	//
	//			count = stmt.executeUpdate();
	//
	//		}catch(SQLException e) {
	//			e.printStackTrace();
	//		}
	//		return count;
	//	}


	//		//顧客が入力したじょうほうをもとに、空いている日にちを引っ張ってくるメソッド　(邉見変更分)
	//		public ArrayList<Integer> getDate(int nameNum,Date date,int menuTime){
	//			//メニューの合計時間は合計したものを引数で受け取る
	//			ArrayList<Integer> list = new ArrayList<>();
	//			ArrayList<Integer> list2 = new ArrayList<>();
	//			java.sql.Date d = new java.sql.Date(date.getTime());
	//
	//			String sql = "SELECT starttime FROM booktable where staffid =" + nameNum + " and hiduke = '" + d + "'";
	//
	//			try(Statement stmt = con.createStatement();
	//					ResultSet result = stmt.executeQuery(sql)){		
	//
	//				while(result.next()) {//実行結果の取得
	//					int time = result.getInt(1);
	//
	//					list.add(time);
	//
	//					//時間が存在しない場合は9-17を格納する(営業時間９時～17時)
	//					if(!(result.next())) {
	//						for(int i = 9; i <= 17; i++) {
	//							list2.add(i);
	//						}
	//					}
	//				}
	//				System.out.println(list);
	//
	//				//空いている予約枠をlistに格納する
	//				for(int i = 9; i <= 17; i++) {
	//					if(list.contains(i)) {
	//						continue;
	//					}
	//					list2.add(i);
	//				}
	//
	//			}catch(SQLException e) {
	//				e.printStackTrace();
	//			}
	//			int count = 0;
	//			int y = 0;
	//
	//			for(int i = 0; i < list.size(); i++) {
	//				if(list.get(i) == y+1) {
	//					count++;
	//					y = list.get(i);
	//					if(count >= menuTime) {
	//						list2.add( y - (menuTime - 1));
	//					}
	//				}else {
	//					count = 1;
	//					y = list.get(i);
	//				}
	//			}
	//			return list2;			
	//		}
	//

}
