package jp.example;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class C_CancelPanel extends JPanel implements ActionListener{
	private JTable table;
	private JTextField customerid;
	private JTextField id;
	private DefaultTableModel model;

	/**
	 * Create the panel.
	 */
	public C_CancelPanel() {
		setBounds(0, 0, 562, 529);//パネルサイズ
		setLayout(null);//絶対レイアウト

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(463, 481, 73, 21);
		ReturnButton.addActionListener(this);
		ReturnButton.setActionCommand("メインへ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("キャンセルパネル");
		lblNewLabel.setBounds(36, 31, 143, 13);
		add(lblNewLabel);


		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 152, 514, 183);
		add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);


		//表示
		String[] bookColumnNames = {"予約番号","日付","開始時間","担当者","顧客名","メニュー1","メニュー2"};
		Object[][] bookData = {};
		model = new DefaultTableModel(bookData,bookColumnNames);
		JTable table = new JTable(model);
		scrollPane.setViewportView(table);

		//検索
		JLabel lblNewLabel_1 = new JLabel("顧客番号");
		lblNewLabel_1.setBounds(56, 100, 73, 13);
		add(lblNewLabel_1);

		customerid = new JTextField();
		customerid.setBounds(141, 97, 96, 19);
		add(customerid);
		customerid.setColumns(10);

		JButton btnNewButton = new JButton("予約内容表示");
		btnNewButton.setBounds(380, 96, 122, 21);
		add(btnNewButton);

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(customerid.getText().isBlank()) {
					dialog("入力エラー","顧客番号を入力してください");
				}else {

					ArrayList<M_customer> mclist =new  ArrayList<>();
					AccessDB.getInstance().connect();
					mclist = AccessDB.getInstance().getM_customerList();
					AccessDB.getInstance().disconnect();
					int count = 0;
					for(M_customer m : mclist) {
						if(Integer.parseInt(customerid.getText())==m.getCustomerid()) {
							count++;
						}
					}
					if(count==0) {
						dialog("入力エラー","存在しない顧客番号です");
					}else{
						model.setRowCount(0);
						ArrayList<M_reservation> list = new ArrayList<>();
						AccessDB.getInstance().connect();
						list = AccessDB.getInstance().getReservationList(Integer.parseInt(customerid.getText()));
						AccessDB.getInstance().disconnect();

						if(list.size()==0) {
							dialog("検索エラー","予約がありません");
						}	else {
							String starttime = "";
							for(M_reservation m : list) {
								switch (m.getStarttime()) {
								case 1:starttime = "9:00";break;
								case 2:starttime = "10:00";break;
								case 3:starttime = "11:00";break;
								case 4:starttime = "12:00";break;
								case 5:starttime = "13:00";break;
								case 6:starttime = "14:00";break;
								case 7:starttime = "15:00";break;
								case 8:starttime = "16:00";break;
								case 9:starttime = "17:00";break;
								case 10:starttime = "18:00";break;
								}
								Object[] o = {m.getId(),m.getHiduke(),starttime,m.getStaffname(),m.getCustomername(),m.getMenuname1(),m.getMenuname2()};
								model.addRow(o);
							}
						}
					}
					customerid.setText("");
				}
			}
		});

		//キャンセル
		JLabel lblNewLabel_2 = new JLabel("予約番号");
		lblNewLabel_2.setBounds(56, 386, 50, 13);
		add(lblNewLabel_2);

		id = new JTextField();
		id.setBounds(141, 383, 96, 19);
		add(id);
		id.setColumns(10);

		JButton btnNewButton_1 = new JButton("キャンセル");
		btnNewButton_1.setBounds(380, 382, 122, 21);
		add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(id.getText().isBlank()) {
					dialog("入力エラー","予約番号を入力してください");
				}else {
					//ダイアログ
					int ret = JOptionPane.showConfirmDialog(null, "本当にキャンセルしますか？", "キャンセル確認", JOptionPane.YES_NO_OPTION , JOptionPane.WARNING_MESSAGE);

					switch(ret) {
					case JOptionPane.YES_OPTION:
						AccessDB.getInstance().connect();
						int count = AccessDB.getInstance().deleteList(Integer.parseInt(id.getText()));
						AccessDB.getInstance().disconnect();		

						if(count != 0) {
							dialog("キャンセル確認","キャンセルしました");
							model.setRowCount(0);
						}else {
							dialog("キャンセル確認","キャンセルできませんでした");
						}
						break;

					case JOptionPane.NO_OPTION:
						dialog("キャンセル確認","キャンセルを取りやめました");
						break;
					}
				}
			}
		});
	}

	public void dialog(String messege1,String messege2) {

		JDialog d = new JDialog();
		d.setTitle(messege1);
		d.setSize(300, 200);
		d.setLocationRelativeTo(null);
		d.setModal(true);

		JLabel messageLabel = new JLabel(messege2);
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		JButton dialogButton = new JButton("OK");
		dialogButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.dispose(); // Close the dialog
			}
		});
		d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		d.setVisible(true);	
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("メインへ")) {
			model.setRowCount(0);
			Main.card.show(Main.CardLayoutPanel, "メインパネル");
		}
	}
}
