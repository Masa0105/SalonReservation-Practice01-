package jp.example;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;

public class C_ReservationPanel extends JPanel implements ActionListener {
	private JTextField date;
	private JTextField selectmenu;

	AccessDB db;
	private JTextField idfield;

	/**
	 * Create the panel.
	 */
	public C_ReservationPanel() {
		db = AccessDB.getInstance();
		setBounds(0, 0, 579, 580);

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(410, 498, 73, 21);
		ReturnButton.addActionListener(this);
		setLayout(null);
		ReturnButton.setActionCommand("メインへ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("予約パネル");
		lblNewLabel.setBounds(10, 8, 143, 13);
		add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("希望日");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_1.setBounds(116, 132, 59, 13);
		add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("担当者選択");
		lblNewLabel_2.setBounds(92, 270, 73, 13);
		add(lblNewLabel_2);

		JLabel lblNewLabel_4 = new JLabel("メニュー選択");
		lblNewLabel_4.setBounds(92, 187, 94, 13);
		add(lblNewLabel_4);

		JLabel lblNewLabel_9 = new JLabel("会員番号入力");
		lblNewLabel_9.setBounds(80, 75, 95, 13);
		add(lblNewLabel_9);

		JLabel lblNewLabel_3 = new JLabel("施術時間合計");
		lblNewLabel_3.setBounds(92, 391, 78, 13);
		add(lblNewLabel_3);




		//会員番号入力フィールド
		idfield = new JTextField();
		idfield.setBounds(214, 72, 86, 19);
		add(idfield);
		idfield.setColumns(10);


		//希望日選択
		//１週間表示のコンボボックス

		JComboBox<LocalDate> comboBox = new JComboBox<>();

		LocalDate today = LocalDate.now();
		LocalDate tomorrow = today.plusDays(1);
		LocalDate futukago = today.plusDays(2);
		LocalDate mikkago = today.plusDays(3);
		LocalDate yokkkago = today.plusDays(4);
		LocalDate itukago = today.plusDays(5);
		LocalDate muikago = today.plusDays(6);

		LocalDate[] days = {today,tomorrow,futukago,mikkago,yokkkago,itukago,muikago};
		for(int i = 0; i < days.length;i++) {			
			comboBox.addItem(days[i]);
		}

		comboBox.setBounds(210, 128, 116, 20);
		add(comboBox);



		//メニューコンボボックスにDBからひっぱってきたものを入れる
		ArrayList<M_menu> menuList = new ArrayList<>();
		String[] m = new String[menuList.size()];

		AccessDB.getInstance().connect();
		menuList = AccessDB.getInstance().getM_menuList();
		AccessDB.getInstance().disconnect();

		JComboBox menucomboBox = new JComboBox();
		for(int i = 0; i < menuList.size(); i++) {
			menucomboBox.addItem(menuList.get(i).getMenuname());
		}
		menucomboBox.setBounds(210, 177, 143, 33);
		add(menucomboBox);

		JComboBox menucomboBox2 = new JComboBox();
		for(int i = 0; i < menuList.size(); i++) {
			menucomboBox2.addItem(menuList.get(i).getMenuname());
		}
		menucomboBox2.setBounds(382, 177, 132, 33);
		add(menucomboBox2);



		//担当者選択
		ArrayList<M_staff> staffList = new ArrayList<>();
		String[] s = new String[staffList.size()];

		AccessDB.getInstance().connect();
		staffList = AccessDB.getInstance().getM_staffList();
		AccessDB.getInstance().disconnect();


		JComboBox<String> tanntousha = new JComboBox<>();
		for(int i = 0; i < staffList.size(); i++) {
			tanntousha.addItem(staffList.get(i).getStaffname());

		}

		tanntousha.setBounds(210, 266, 109, 21);
		add(tanntousha);

		//施術合計時間表示パネル
		JTextPane textPane = new JTextPane();
		textPane.setBounds(210, 383, 48, 21);
		add(textPane);

		//単位
		JLabel lblNewLabel_6 = new JLabel("時間");
		lblNewLabel_6.setBounds(268, 391, 66, 13);
		add(lblNewLabel_6);




		//予約時間検索
		JButton sarch = new JButton("予約時間検索");

		JComboBox timeselect = new JComboBox();
		timeselect.setBounds(210, 417, 109, 21);
		add(timeselect);

		sarch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//コンボボックスの中身を一旦空にする
				timeselect.removeAllItems();

				//担当者のIDを引っ張ってくる
				int nameNum = 0;
				ArrayList<M_staff> list = new ArrayList<>();
				ArrayList<Integer> list2 = new ArrayList<>();

				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getM_staffList();
				AccessDB.getInstance().disconnect();
				for(M_staff i : list) {
					if(tanntousha.getSelectedItem().equals(i.getStaffname())) {
						nameNum = i.getStaffid();
					}
				}


				//コンボボックスで選んだメニューの合計所要時間を計算
				ArrayList<M_menu> menulist = new ArrayList<>();
				AccessDB.getInstance().connect();
				menulist = AccessDB.getInstance().getM_menuList();
				AccessDB.getInstance().disconnect();
				int sumtime =0;
				for(M_menu m1 :menulist) {
					if(menucomboBox.getSelectedItem().equals(m1.getMenuname())) {
						sumtime += m1.getMenutime();
					}
					if(menucomboBox2.getSelectedItem().equals(m1.getMenuname())) {
						sumtime += m1.getMenutime();
					}
				}

				//メニュー合計時間のフィールドに表示させる

				textPane.setText(Integer.toString(sumtime));

				//メニューの合計時間が0の場合はダイアログ表示でもう一度メニューの入力をさせる
				if(sumtime == 0) {
					//JDialogのインスタンスを作る
					JDialog d1 = new JDialog();
					//ダイアログにタイトルをつける
					d1.setTitle("メニュー再度選択");
					//ダイアログのサイズを指定する
					d1.setSize(300, 200);
					//ダイアログの表示場所。Nullなら画面中央。
					d1.setLocationRelativeTo(null);
					// ダイアログをモーダルダイアログとして設定
					// モーダルの時は他のウインドウとかの操作をブロックできる
					d1.setModal(true);

					JLabel messageLabel = new JLabel("メニューをひとつ以上選んで、再度予約時間検索ボタンを押してください");
					messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
					d1.getContentPane().add(messageLabel, BorderLayout.CENTER);

					// ダイアログにコンポーネントを追加
					//									// ダイアログにテキストフィールドを追加
					//									JTextField textField = new JTextField();
					//									d.getContentPane().add(textField, BorderLayout.NORTH);
					// ダイアログにボタンを追加
					JButton dialogButton = new JButton("OK");


					dialogButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							d1.dispose(); // Close the dialog
						}
					});
					d1.getContentPane().add(dialogButton, BorderLayout.SOUTH);
					// ダイアログの表示
					d1.setVisible(true);


				}


				////getDateメソッドに渡して空いている予約枠を引っ張てくる
				LocalDate lo = (LocalDate)comboBox.getSelectedItem();
				DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String ss = lo.format(fmt);

				SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
				Date d = new Date();
				try {
					d = f.parse(ss);
				}catch(ParseException e1) {
					e1.printStackTrace();
				}

				//Date d = java.sql.Date.valueOf((String)comboBox.getSelectedItem());

				AccessDB.getInstance().connect();
				list2 = AccessDB.getInstance().getDate(nameNum,d,sumtime);
				AccessDB.getInstance().disconnect();



				//コンボボックスに表示させる	
				//JComboBox timeselect = new JComboBox();
				//				for(int i = 0; i < list2.size(); i++) {
				//					timeselect.addItem(list2.get(i));
				//					}
				//				}
				//（時間表示）
				for(int i = 0; i < list2.size(); i++) {
					switch (list2.get(i)) {
					case 1:timeselect.addItem("9:00");break;
					case 2:timeselect.addItem("10:00");break;
					case 3:timeselect.addItem("11:00");break;
					case 4:timeselect.addItem("12:00");break;
					case 5:timeselect.addItem("13:00");break;
					case 6:timeselect.addItem("14:00");break;
					case 7:timeselect.addItem("15:00");break;
					case 8:timeselect.addItem("16:00");break;
					case 9:timeselect.addItem("17:00");break;
					case 10:timeselect.addItem("18:00");break;
					}

				}

			}


		});
		sarch.setBounds(210, 302, 120, 21);
		add(sarch);

		//予約可能時間表示、選択
		JLabel lblNewLabel_5 = new JLabel("予約可能時間を選択");
		lblNewLabel_5.setBounds(59, 421, 116, 13);
		add(lblNewLabel_5);



		JButton yoyaku = new JButton("予約");
		yoyaku.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(idfield.getText().isBlank()) {
					dialog("入力エラー","顧客番号を入力してください");
				} else {
					ArrayList<M_customer> mclist =new  ArrayList<>();
					AccessDB.getInstance().connect();
					mclist = AccessDB.getInstance().getM_customerList();
					AccessDB.getInstance().disconnect();
					int count = 0;
					for(M_customer m : mclist) {
						if(Integer.parseInt(idfield.getText())==m.getCustomerid()) {
							count++;
						}
					}

					if(count==0) {
						dialog("入力エラー","存在しない顧客番号です");
					}
					else {

						//処理する内容を書く

						//ID(int id)
						int id = 0;
						ArrayList<M_reservation> mlist = new ArrayList<>();
						AccessDB.getInstance().connect();
						mlist = AccessDB.getInstance().getAllList();
						AccessDB.getInstance().disconnect();

						int max = 0;
						for(M_reservation i : mlist){
							if(i.getId() > max) {
								max = i.getId();
								System.out.println(max);
							}
						}

						System.out.println(max);
						max++;
						id = ++max;

						System.out.println(id);



						//日付(Date d)
						LocalDate lo = (LocalDate)comboBox.getSelectedItem();
						DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						String ss = lo.format(fmt);

						SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
						Date d = new Date();
						try {
							d = f.parse(ss);
						}catch(ParseException e1) {
							e1.printStackTrace();
						}

						//予約時間(int starttime)
						String str = (String)timeselect.getSelectedItem();
						int starttime = 0;
						switch (str) {
						case "9:00":starttime = 1;break; 
						case "10:00":starttime = 2;break; 
						case "11:00":starttime = 3;break; 
						case "12:00":starttime = 4;break; 
						case "13:00":starttime = 5;break; 
						case "14:00":starttime = 6;break; 
						case "15:00":starttime = 7;break; 
						case "16:00":starttime = 8;break; 
						case "17:00":starttime = 9;break; 
						case "18:00":starttime = 10;break;			

						}

						//スタッフID(int staffid)
						int staffid = 0;
						ArrayList<M_staff> stafflist = new ArrayList<>();
						AccessDB.getInstance().connect();
						stafflist = AccessDB.getInstance().getM_staffList();
						AccessDB.getInstance().disconnect();
						for(M_staff i : stafflist) {
							if(tanntousha.getSelectedItem().equals(i.getStaffname())) {
								staffid = i.getStaffid();
							}
						}

						//カスタマーID(int costomerid)
						int costomerid = Integer.parseInt(idfield.getText());

						//menuID 1(int menu1)
						ArrayList<M_menu> menulist = new ArrayList<>();
						int menu1 = 0;
						AccessDB.getInstance().connect();
						menulist = AccessDB.getInstance().getM_menuList();
						AccessDB.getInstance().disconnect();
						for(M_menu i : menulist) {
							if(menucomboBox.getSelectedItem().equals(i.getMenuname())) {
								menu1 = i.getMenuid();
							}
						}				

						//menuID 2(int menu2)
						int menu2 = 0;
						for(M_menu i : menulist) {
							if(menucomboBox2.getSelectedItem().equals(i.getMenuname())) {
								menu2 = i.getMenuid();
							}
						}				

						//データベースに予約を追加
						AccessDB.getInstance().connect();
						int x = AccessDB.getInstance().insertM_reservation(id,d,starttime,staffid,costomerid,menu1,menu2);
						AccessDB.getInstance().disconnect();
						
						dialog("新規予約登録","予約を受付けました");


					}
				}
			}
		});

		yoyaku.setBounds(210, 456, 87, 21);
		add(yoyaku);

		//		JTextPane textPane_1 = new JTextPane();
		//		textPane_1.setText("1： 9時～\r\n2：10時～\r\n3：11時～\r\n4：12時～\r\n5：13時～\r\n6：14時～\r\n7：15時～\r\n8：16時～\r\n9：17時～\r\n10：18時～");
		//		textPane_1.setBounds(387, 318, 96, 172);
		//		add(textPane_1);




	}
	public void dialog(String messege1,String messege2) {

		JDialog d = new JDialog();
		d.setTitle(messege1);
		d.setSize(300, 200);
		d.setLocationRelativeTo(null);
		d.setModal(true);

		JLabel messageLabel = new JLabel(messege2);
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		JButton dialogButton = new JButton("OK");
		dialogButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.dispose(); // Close the dialog
			}
		});
		d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		d.setVisible(true);	
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("メインへ")) {
			Main.card.show(Main.CardLayoutPanel, "メインパネル");
		}
	}
}
