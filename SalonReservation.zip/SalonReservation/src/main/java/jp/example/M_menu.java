package jp.example;

public class M_menu {
	private int menuid;
	private String menuname;
	private int menutime;
	private int price;

	M_menu(){}
	
	M_menu(int menuid,String menuname,int menutime,int price){
		setMenuid(menuid);
		setMenuname(menuname);
		setMenutime(menutime);
		setPrice(price);
	}	
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getMenuid() {
		return menuid;
	}
	public void setMenuid(int menuid) {
		this.menuid = menuid;
	}
	public String getMenuname() {
		return menuname;
	}
	public void setMenuname(String menuname) {
		this.menuname = menuname;
	}
	public int getMenutime() {
		return menutime;
	}
	public void setMenutime(int menutime) {
		this.menutime = menutime;
	}
}
