package jp.example;

import java.sql.Date;

public class M_reservation {
	private int id;
	private Date hiduke;
	private int starttime;
	private String menuname1;
	private String menuname2;
	private String staffname;
	private String customername;
	private int price1;
	private int price2;

	M_reservation(int id,Date hiduke,int starttime,String staffname,String customername,String menuname1,int price1,String menuname2,int price2){
		setId(id);
		setHiduke(hiduke);
		setStarttime(starttime);
		setStaffname(staffname);
		setCustomername(customername);
		setMenuname1(menuname1);
		setMenuname2(menuname2);
		setPrice1(price1);
		setPrice2(price2);
	}

	M_reservation(){
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getHiduke() {
		return hiduke;
	}
	public void setHiduke(Date hiduke) {
		this.hiduke = hiduke;
	}
	public int getStarttime() {
		return starttime;
	}
	public void setStarttime(int starttime) {
		this.starttime = starttime;
	}

	public void setMenuname1(String menuname1) {
		this.menuname1 = menuname1;
	}

	public String getMenuname1() {
		return menuname1;
	}
	
	public void setMenuname2(String menuname2) {
		this.menuname2 = menuname2;
	}

	public String getMenuname2() {
		return menuname2;
	}

	public String getStaffname() {
		return staffname;
	}

	public void setStaffname(String staffname) {
		this.staffname = staffname;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}	

	public int getPrice1() {
		return price1;
	}

	public void setPrice1(int price1) {
		this.price1 = price1;
	}

	public int getPrice2() {
		return price2;
	}

	public void setPrice2(int price2) {
		this.price2 = price2;
	}
}
