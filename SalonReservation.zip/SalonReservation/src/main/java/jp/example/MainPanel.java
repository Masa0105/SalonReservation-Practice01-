package jp.example;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MainPanel extends JPanel implements ActionListener{

	private Image backgroundImage;

	/**
	 * Create the panel.
	 */
	public MainPanel() {
		setBounds(0, 0, 562, 529);//パネルサイズ
		setLayout(null);//絶対レイアウト

		// 背景画像の読み込み
		InputStream dbImgdisaa = this.getClass().getResourceAsStream("/suita.png");
		ImageIcon icon = null;

		try {
			icon = new ImageIcon(ImageIO.read(dbImgdisaa));

		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}
		backgroundImage = icon.getImage();


		JButton ReservationButton = new JButton("予約");
		ReservationButton.setBounds(210, 260, 110, 20);
		ReservationButton.addActionListener(this);
		setLayout(null);
		ReservationButton.setActionCommand("予約");
		add(ReservationButton);

		JButton ChangeButton = new JButton("変更・確認");
		ChangeButton.setBounds(210, 310, 110, 20);
		ChangeButton.addActionListener(this);
		ChangeButton.setActionCommand("変更");
		add(ChangeButton);

		JButton CancelButton = new JButton("キャンセル");
		CancelButton.setBounds(210, 350, 110, 20);
		CancelButton.addActionListener(this);
		CancelButton.setActionCommand("キャンセル");
		add(CancelButton);

		JButton ManagerButton = new JButton("店長");
		ManagerButton.setBounds(466, 481, 69, 21);
		ManagerButton.addActionListener(this);
		ManagerButton.setActionCommand("店長へ");
		add(ManagerButton);		

		JButton EntryButton = new JButton("新規登録");
		EntryButton.setBounds(210, 130, 110, 20);
		EntryButton.addActionListener(this);
		EntryButton.setActionCommand("新規登録");
		add(EntryButton);

		JLabel lblNewLabel = new JLabel("初めての方はご登録願います");
		lblNewLabel.setFont(new Font("MS UI Gothic", Font.PLAIN, 14));
		lblNewLabel.setBounds(188, 80, 197, 21);
		add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("会員の方はコチラ");
		lblNewLabel_1.setFont(new Font("MS UI Gothic", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(213, 220, 147, 21);
		add(lblNewLabel_1);



	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		// 背景画像の描画
		g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("予約")) {
			C_ReservationPanel ReservationPanel = new C_ReservationPanel();
			Main.CardLayoutPanel.add(ReservationPanel, "予約パネル");
			Main.card.show(Main.CardLayoutPanel, "予約パネル");
		}

		if(e.getActionCommand().equals("変更")) {
			C_ChangePanel ChangePanel = new C_ChangePanel();
			Main.CardLayoutPanel.add(ChangePanel, "変更パネル");
			Main.card.show(Main.CardLayoutPanel, "変更パネル");
		}

		if(e.getActionCommand().equals("キャンセル")) {
			C_CancelPanel CancelPanel = new C_CancelPanel();
			Main.CardLayoutPanel.add(CancelPanel, "キャンセルパネル");
			Main.card.show(Main.CardLayoutPanel, "キャンセルパネル");
		}

		if(e.getActionCommand().equals("新規登録")) {
			C_EntryPanel EntryPanel = new C_EntryPanel();
			Main.CardLayoutPanel.add(EntryPanel, "新規登録パネル");
			Main.card.show(Main.CardLayoutPanel, "新規登録パネル");
		}

		if(e.getActionCommand().equals("店長へ")) {
			//JDialogのインスタンスを作る
			JDialog d = new JDialog();
			//ダイアログにタイトルをつける
			d.setTitle("パスワードを入力してください");
			//ダイアログのサイズを指定する
			d.setSize(300, 200);
			//ダイアログの表示場所。Nullなら画面中央。
			d.setLocationRelativeTo(null);
			d.setModal(true);

			JTextField textField = new JTextField();

			d.getContentPane().add(textField, BorderLayout.NORTH);
			// ダイアログにボタンを追加
			JButton dialogButton = new JButton("OK");		
			dialogButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String choicepass = textField.getText();

					if (choicepass.equals("1234")) {

						Main.card.show(Main.CardLayoutPanel, "店長パネル");
						d.dispose(); // Close the dialog
					}

				}
			});
			d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
			// ダイアログの表示
			d.setVisible(true);
		}


	}
}
