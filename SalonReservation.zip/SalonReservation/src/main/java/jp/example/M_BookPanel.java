package jp.example;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class M_BookPanel extends JPanel implements ActionListener{
	private JTable table;
	private JTextField customerid;
	private DefaultTableModel model;
	private JTextField staffid;

	ArrayList<M_reservation> list = new ArrayList<>();
	ArrayList<M_customer> list2 = new ArrayList<>();
	ArrayList<M_staff> list3 = new ArrayList<>();
	
	/**
	 * Create the panel.
	 */
	public M_BookPanel() {
		setBackground(new Color(240, 240, 240));
		setBounds(0, 0, 610, 529);//パネルサイズ
		setLayout(null);//絶対レイアウト

		JButton ReturnButton = new JButton("戻る");
		ReturnButton.setBounds(463, 481, 73, 21);
		ReturnButton.addActionListener(this);
		ReturnButton.setActionCommand("店長へ");
		add(ReturnButton);

		JLabel lblNewLabel = new JLabel("予約台帳パネル");
		lblNewLabel.setBounds(36, 31, 143, 13);
		add(lblNewLabel);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 97, 515, 181);
		add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);



		//表示
		String[] bookColumnNames = {"予約番号","日付","開始時間","担当者","顧客名","メニュー","メニュー2"};
		Object[][] bookData = {};
		model = new DefaultTableModel(bookData,bookColumnNames);
		JTable table = new JTable(model);
		scrollPane.setViewportView(table);

		JButton showBook = new JButton("一覧表示");
		showBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				model.setRowCount(0);
				AccessDB.getInstance().connect();
				list = AccessDB.getInstance().getAllList();
				list2 = AccessDB.getInstance().getM_customerList();//顧客情報
				list3 = AccessDB.getInstance().getM_staffList();//従業員情報
				AccessDB.getInstance().disconnect();
				
				
				
				for(M_reservation m : list) {
					
					int customerId = 0;
					int staffId = 0;
					for(M_customer c :list2) {
						if(m.getCustomername().equals(c.getCustomername())){
							customerId = c.getCustomerid();
						}
					}
					for(M_staff s :list3) {
						if(m.getStaffname().equals(s.getStaffname())){
							staffId = s.getStaffid();
						}
					}
					
					String sTime = "";
					switch (m.getStarttime()) {
					case 1:sTime = "9:00";break;
					case 2:sTime = "10:00";break;
					case 3:sTime = "11:00";break;
					case 4:sTime = "12:00";break;
					case 5:sTime = "13:00";break;
					case 6:sTime = "14:00";break;
					case 7:sTime = "15:00";break;
					case 8:sTime = "16:00";break;
					case 9:sTime = "17:00";break;
					case 10:sTime = "18:00";break;
					}
					
					
					Object[] o = {m.getId(),m.getHiduke(),sTime,staffId + ":" + m.getStaffname(),customerId + ":" + m.getCustomername(),m.getMenuname1(),m.getMenuname2()};
					model.addRow(o);
				}
			}
		});
		showBook.setBounds(236, 55, 91, 21);
		add(showBook);

		//検索	
		JLabel lblNewLabel_1 = new JLabel("顧客番号");
		lblNewLabel_1.setBounds(54, 308, 73, 13);
		add(lblNewLabel_1);

		customerid = new JTextField();
		customerid.setBounds(154, 305, 96, 19);
		add(customerid);
		customerid.setColumns(10);

		JButton btnNewButton = new JButton("顧客番号で検索");
		btnNewButton.setBounds(345, 304, 155, 21);
		add(btnNewButton);

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(customerid.getText().isBlank()) {
					dialog("入力エラー","顧客番号を入力してください");
				}else {
					model.setRowCount(0);
					AccessDB.getInstance().connect();
					list = AccessDB.getInstance().getReservationList(Integer.parseInt(customerid.getText()));
					AccessDB.getInstance().disconnect();
					if(list.size()==0) {
						
						dialog("検索エラー","予約がありません");

					}else {
						for(M_reservation m : list) {int customerId = 0;
						int staffId = 0;
						for(M_customer c :list2) {
							if(m.getCustomername().equals(c.getCustomername())){
								customerId = c.getCustomerid();
							}
						}
						for(M_staff s :list3) {
							if(m.getStaffname().equals(s.getStaffname())){
								staffId = s.getStaffid();
							}
						}
						
						String sTime = "";
						switch (m.getStarttime()) {
						case 1:sTime = "9:00";break;
						case 2:sTime = "10:00";break;
						case 3:sTime = "11:00";break;
						case 4:sTime = "12:00";break;
						case 5:sTime = "13:00";break;
						case 6:sTime = "14:00";break;
						case 7:sTime = "15:00";break;
						case 8:sTime = "16:00";break;
						case 9:sTime = "17:00";break;
						case 10:sTime = "18:00";break;
						}
						
						
						Object[] o = {m.getId(),m.getHiduke(),sTime,staffId + ":" + m.getStaffname(),customerId + ":" + m.getCustomername(),m.getMenuname1(),m.getMenuname2()};
						model.addRow(o);
						}
						customerid.setText("");
					}
				}
			}
		});	

		JLabel lblNewLabel_2 = new JLabel("スタッフ番号");
		lblNewLabel_2.setBounds(54, 355, 88, 13);
		add(lblNewLabel_2);

		staffid = new JTextField();
		staffid.setBounds(154, 352, 96, 19);
		add(staffid);
		staffid.setColumns(10);

		JButton btnNewButton_2 = new JButton("スタッフ番号で検索");
		btnNewButton_2.setBounds(345, 351, 155, 21);
		add(btnNewButton_2);

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(staffid.getText().isBlank()) {
					dialog("入力エラー","スタッフ番号");
				}else {
					model.setRowCount(0);
					AccessDB.getInstance().connect();
					list = AccessDB.getInstance().getReservationList2(Integer.parseInt(staffid.getText()));
					AccessDB.getInstance().disconnect();
					if(list.size()==0) {
						
						dialog("検索エラー","予約がありません");
						
					}else {
						for(M_reservation m : list) {
							
							int customerId = 0;
							int staffId = 0;
							for(M_customer c :list2) {
								if(m.getCustomername().equals(c.getCustomername())){
									customerId = c.getCustomerid();
								}
							}
							for(M_staff s :list3) {
								if(m.getStaffname().equals(s.getStaffname())){
									staffId = s.getStaffid();
								}
							}
							
							String sTime = "";
							switch (m.getStarttime()) {
							case 1:sTime = "9:00";break;
							case 2:sTime = "10:00";break;
							case 3:sTime = "11:00";break;
							case 4:sTime = "12:00";break;
							case 5:sTime = "13:00";break;
							case 6:sTime = "14:00";break;
							case 7:sTime = "15:00";break;
							case 8:sTime = "16:00";break;
							case 9:sTime = "17:00";break;
							case 10:sTime = "18:00";break;
							}
							
							
							Object[] o = {m.getId(),m.getHiduke(),sTime,staffId + ":" + m.getStaffname(),customerId + ":" + m.getCustomername(),m.getMenuname1(),m.getMenuname2()};
							model.addRow(o);
						}
						customerid.setText("");
					}
				}
			}
		});	
	}
	
	
	public void dialog(String messege1,String messege2) {

		JDialog d = new JDialog();
		d.setTitle(messege1);
		d.setSize(300, 200);
		d.setLocationRelativeTo(null);
		d.setModal(true);

		JLabel messageLabel = new JLabel(messege2);
		messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		d.getContentPane().add(messageLabel, BorderLayout.CENTER);
		JButton dialogButton = new JButton("OK");
		dialogButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.dispose(); // Close the dialog
			}
		});
		d.getContentPane().add(dialogButton, BorderLayout.SOUTH);
		d.setVisible(true);	
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("店長へ")) {
			model.setRowCount(0);
			customerid.setText("");
			staffid.setText("");
			Main.card.show(Main.CardLayoutPanel, "店長パネル");
		}
	}
}
